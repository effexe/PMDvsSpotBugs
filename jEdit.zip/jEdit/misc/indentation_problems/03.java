if (true
    && fun(a ? x 

/*
Adding : to the second line shouldn't reindent.
*/

if (true
    && fun(a ? x :  
