void f() {
  std
}

/*
At the end of line 2 type ::
At first : it should go left, at second : be back.
*/

void f() {
  std::
}
